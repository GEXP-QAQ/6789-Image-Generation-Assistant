---
name: relay-image-generator
description: Generate or edit up to 50 images concurrently through the 6789api relay from persistent panel settings. Start or reuse the panel before checking the API key, keep the panel tab open across task and browser-session cleanup, skip browser control when that exact panel is already open, use one streaming generation command, minimize normal-response tokens, and return saved images inline immediately. Use for 6789api, gpt-image-2, nano-banana, Gemini image preview, or relay requests fixed to https://www.6789api.top/v1.
---

# Relay Image Generator

- Reply in Chinese; use only `https://www.6789api.top/v1`.
- Panel values are read-only and override chat parameters. Never ask about, suggest, change, infer, reset, or override them.
- Treat panel startup as a mandatory gate before every other action, including prompt work and API-key checks.
- Use in-app Browser control only to open or focus the exact localhost URL returned by `ensure-panel.mjs`. Do not inspect the DOM, controls, source, state, settings/status endpoints, model lists, or API references during normal generation.
- Keep the panel service/tab untouched and open after every outcome, including an API-key pause, success, or failure. Never close it or leave a controlled panel tab eligible for automatic browser-session cleanup.
- Accept the API key only from this conversation. Check or ask for it only after the panel is open. Never find, store, log, display, or echo it.
- Never alter parameters on failure or run extra tools after success.
- Minimize user token usage: use one short progress update, omit parameter recaps and workflow explanations, and return only the successful count, inline images, and path links after success.

## Startup Gate

Perform these steps before composing the prompt or asking for a key:

1. Run `node scripts/ensure-panel.mjs` and capture its single localhost URL.
2. If the supplied in-app-browser context already shows that exact URL, treat the panel as open and do not load browser-control instructions or make browser calls. Otherwise open or focus that URL in the Codex in-app browser and keep the tab visible.
3. When browser control was needed, immediately preserve the panel tab with `browser.tabs.finalize({ keep: [{ tab: panelTab, status: "deliverable" }] })`. Use the actual browser and tab bindings. This must be the final browser action, and it must happen before checking for the API key or running generation. Never finalize without keeping the panel, use `handoff` for it, or rely on automatic session cleanup.
4. Do not inspect or operate the panel controls. The persistent service synchronizes them for the generator.
5. If the panel cannot be opened or preserved, stop and report the URL or startup error. Do not ask for the API key until the panel is both available and protected from browser-session cleanup.
6. Only after the panel is open and preserved, check whether a 6789api key was supplied in the current conversation. If it is missing, ask for it and pause.

## Run

1. After the startup gate and key check, make a concise prompt; use `--prompt-file FILE` with UTF-8 only above 3500 characters.
2. Run exactly once with the URL returned by the startup gate; add repeated `--image` only for reference images:

```shell
node scripts/generate-from-panel.mjs --panel-url "PANEL_URL" --prompt "一只坐在窗边的白猫" --api-key "USER_PASTED_KEY"
```

3. Each stdout line is a completed path streamed as soon as that image is saved. Do not poll more often than needed. After completion, immediately return each as `![生成图片 N](</absolute/path.png>)` plus `[打开原图](</absolute/path.png>)`; inspect nothing afterward.

On generation failure, report it; read `references/relay-api.md` only for necessary troubleshooting and do not generate again without explicit authorization.
