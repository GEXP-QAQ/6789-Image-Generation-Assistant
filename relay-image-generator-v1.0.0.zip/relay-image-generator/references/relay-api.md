# Relay API Reference

Use this reference when troubleshooting or changing 6789api image relay calls.

## Endpoint Shape

Use only this relay base URL:

```text
https://www.6789api.top/v1
```

Assume OpenAI-compatible endpoints under that base URL for `gpt-image-2` models:

- Text-to-image: `POST /images/generations`
- Image edit/reference generation: `POST /images/edits`

Use the beta Gemini content endpoint for `gemini-*` and `nano-banana-*` image models:

- Text-to-image and reference-image generation: `POST https://www.6789api.top/v1beta/models/{model}:generateContent`

Do not use this skill with other relay providers or alternate base URLs.

## Key Handling

- Obtain the API key only through the current conversation.
- If no key has been pasted, ask the user to paste their `https://www.6789api.top/v1` API key.
- If the user has no key, tell them to register at `https://www.6789api.top/`, create an API key, and paste it back.
- Pass the key with `--api-key`.
- Do not read `IMAGE_RELAY_API_KEY`, `.env`, shell history, browser storage, or unrelated local files.

## Payload Strategy

`gpt-image-2` text-to-image requests use JSON:

```json
{
  "model": "gpt-image-2",
  "prompt": "...",
  "size": "1536x2048",
  "quality": "high",
  "n": 1
}
```

`gpt-image-2` image-edit requests use multipart form data with `model`, `prompt`, optional parameters, and one or more `image` parts.

Gemini/nano-banana text-to-image and reference-image requests use JSON:

```json
{
  "contents": [
    {
      "role": "user",
      "parts": [
        { "text": "一只坐在窗边的白猫，电影感光影" },
        {
          "inlineData": {
            "mimeType": "image/png",
            "data": "去掉 data:image/png;base64, 前缀后的 base64"
          }
        }
      ]
    }
  ],
  "generationConfig": {
    "topP": 0.95,
    "responseModalities": ["IMAGE"],
    "imageConfig": {
      "aspectRatio": "1:1",
      "imageSize": "2K"
    }
  }
}
```

Some relays reject optional OpenAI parameters. In the live-panel workflow, report that error without changing or omitting the user's parameters. Never retry automatically with `--minimal`. Use `--minimal` only during standalone troubleshooting after the user explicitly authorizes a compatibility test, because it omits `size`, `quality`, and `n`.

## Concurrent Generation

- Interpret CLI `--n` as the number of independent image requests, not as the relay payload count.
- Accept counts from `1` through `50`; reject larger or invalid values.
- Send `n: 1` in each OpenAI request while preserving the panel's requested concurrent count.
- Start all requested image tasks concurrently so a slow image does not block the others.
- Enforce a 10-minute total deadline per image task across relay attempts, retry delays, and URL download.
- Save successful images even when sibling requests fail. Fail the command only when every request fails.

## Known Models

The relay may expose these model identifiers:

- `gemini-3-pro-image-preview`
- `gemini-3.1-flash-image-preview`
- `nano-banana-2`
- `nano-banana-pro`
- `nano-banana-2-lite`
- `nano-banana-fast`
- `gpt-image-2`
- `gpt-image-2（官方）`

Pass exact names with `--model`. For convenience, the script normalizes these aliases:

- `official`, `gpt-official`, `gpt-image-2-official` -> `gpt-image-2（官方）`
- `banana-pro`, `nano-pro` -> `nano-banana-pro`
- `banana-fast`, `nano-fast` -> `nano-banana-fast`
- `banana-lite`, `nano-lite` -> `nano-banana-2-lite`
- `gemini-pro` -> `gemini-3-pro-image-preview`
- `gemini-flash` -> `gemini-3.1-flash-image-preview`

## Response Handling

The script accepts common image response forms:

- `data[].b64_json`: saves decoded PNG files.
- `data[].url`: downloads the URL and saves the returned bytes.
- `candidates[].content.parts[].inlineData.data`: saves decoded Gemini/nano-banana images.

If neither form appears, inspect the raw response body shown by the script. Do not include API keys when sharing logs.

## Payload Limits

To avoid relay or nginx `413 Payload Too Large` errors:

- Keep prompts under 3500 characters by default.
- Keep each reference image under 5 MB by default.
- Do not paste base64 data into prompts.
- Prefer local image paths for references.

Override only when necessary:

```powershell
$env:IMAGE_RELAY_MAX_PROMPT_CHARS = "6000"
$env:IMAGE_RELAY_MAX_IMAGE_MB = "10"
```

## Environment Overrides

The script reads these optional non-secret variables:

- `IMAGE_RELAY_MODEL`, defaulting to `nano-banana-pro`
- `IMAGE_RELAY_SIZE`
- `IMAGE_RELAY_QUALITY`
- `IMAGE_RELAY_OUTPUT_DIR`
- `IMAGE_RELAY_TIMEOUT_MS`
- `IMAGE_RELAY_RETRIES`
- `IMAGE_RELAY_MAX_PROMPT_CHARS`
- `IMAGE_RELAY_MAX_IMAGE_MB`

Do not use environment variables for API keys or base URL.
Values above `600000` for `IMAGE_RELAY_TIMEOUT_MS` are rejected because the per-image hard limit is 10 minutes.
