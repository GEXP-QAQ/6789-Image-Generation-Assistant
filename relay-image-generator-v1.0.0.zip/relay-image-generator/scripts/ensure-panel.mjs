#!/usr/bin/env node

import { spawn } from "node:child_process";
import { readFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const scriptsDir = dirname(fileURLToPath(import.meta.url));
const skillDir = join(scriptsDir, "..");
const runtimeDir = join(process.env.CODEX_HOME || join(homedir(), ".codex"), "relay-image-generator");
const registryPath = join(runtimeDir, "active-panel.json");

function normalizePanelUrl(value) {
  const url = new URL(value);
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || !url.port) return "";
  return `${url.origin}/`;
}

async function readRegistry() {
  try {
    const registry = JSON.parse(await readFile(registryPath, "utf8"));
    return {
      panelUrl: normalizePanelUrl(registry.panelUrl),
      pid: Number(registry.pid)
    };
  } catch {
    return { panelUrl: "", pid: 0 };
  }
}

async function isLive(panelUrl) {
  if (!panelUrl) return false;
  try {
    const response = await fetch(new URL("settings", panelUrl), {
      cache: "no-store",
      signal: AbortSignal.timeout(400)
    });
    return response.ok;
  } catch {
    return false;
  }
}

let registry = await readRegistry();
if (await isLive(registry.panelUrl)) {
  console.log(registry.panelUrl);
  process.exit(0);
}

const child = spawn(process.execPath, [join(scriptsDir, "serve-panel.mjs")], {
  cwd: skillDir,
  detached: true,
  stdio: "ignore",
  windowsHide: true
});
child.unref();

const deadlineAt = Date.now() + 3000;
while (Date.now() < deadlineAt) {
  await new Promise((resolve) => setTimeout(resolve, 50));
  registry = await readRegistry();
  if (registry.pid === child.pid && await isLive(registry.panelUrl)) {
    console.log(registry.panelUrl);
    process.exit(0);
  }
}

throw new Error("Unable to start the persistent parameter panel.");
