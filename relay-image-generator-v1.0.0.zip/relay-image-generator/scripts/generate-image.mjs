#!/usr/bin/env node

import { mkdir, writeFile } from "node:fs/promises";
import { existsSync, readFileSync, statSync } from "node:fs";
import { Blob } from "node:buffer";
import { execFileSync } from "node:child_process";
import { basename, extname, join, resolve } from "node:path";

const allowedBaseUrl = "https://www.6789api.top/v1";
const betaBaseUrl = "https://www.6789api.top/v1beta";
const maxConcurrentImages = 50;
const maxPerImageTimeoutMs = 10 * 60 * 1000;

const usage = `Usage:
  node scripts/generate-image.mjs --prompt "..." [--api-key KEY]
  node scripts/generate-image.mjs --prompt-file prompt.txt [--image ref.png] [--api-key KEY]
  node scripts/generate-image.mjs --params-file relay-image-params.json --prompt-file prompt.txt [--api-key KEY]
  node scripts/generate-image.mjs --list-models

Options:
  --params-file FILE   Read model, size, quality, n, baseUrl, output options from JSON
  --base-url URL       Must be https://www.6789api.top/v1 when provided
  --model NAME         Defaults to IMAGE_RELAY_MODEL or nano-banana-pro
  --size SIZE          Defaults to IMAGE_RELAY_SIZE or 1536x2048
  --quality VALUE      Defaults to IMAGE_RELAY_QUALITY or high
  --aspect-ratio RATIO Defaults to inferred ratio from --size
  --image-size VALUE   Gemini/nano image size, defaults to 2K
  --n COUNT            Concurrent image requests, 1-50; defaults to 1
  --out DIR            Defaults to Desktop\\Codex中转站生图
  --prefix NAME        Output filename prefix
  --image PATH         Reference image; may be repeated
  --minimal            Omit optional size/quality/n parameters
  --timeout-ms VALUE   Per-image total timeout; maximum 600000 (10 minutes)
  --dry-run            Print request plan without calling the relay
`;

const knownModels = [
  "gemini-3-pro-image-preview",
  "gemini-3.1-flash-image-preview",
  "nano-banana-2",
  "nano-banana-pro",
  "nano-banana-2-lite",
  "nano-banana-fast",
  "gpt-image-2",
  "gpt-image-2（官方）"
];

const modelAliases = new Map([
  ["official", "gpt-image-2（官方）"],
  ["gpt-official", "gpt-image-2（官方）"],
  ["gpt-image-2-official", "gpt-image-2（官方）"],
  ["gpt-image-2官方", "gpt-image-2（官方）"],
  ["gpt-image-2(官方)", "gpt-image-2（官方）"],
  ["banana-2", "nano-banana-2"],
  ["banana-pro", "nano-banana-pro"],
  ["nano-pro", "nano-banana-pro"],
  ["banana-lite", "nano-banana-2-lite"],
  ["nano-lite", "nano-banana-2-lite"],
  ["banana-fast", "nano-banana-fast"],
  ["nano-fast", "nano-banana-fast"],
  ["gemini-pro", "gemini-3-pro-image-preview"],
  ["gemini-flash", "gemini-3.1-flash-image-preview"]
]);

function parseArgs(argv) {
  const args = { image: [] };

  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (!item.startsWith("--")) continue;

    const raw = item.slice(2);
    const equalsIndex = raw.indexOf("=");
    const key = equalsIndex === -1 ? raw : raw.slice(0, equalsIndex);
    const inlineValue = equalsIndex === -1 ? null : raw.slice(equalsIndex + 1);

    if (["dry-run", "help", "minimal", "list-models"].includes(key)) {
      args[key] = true;
      continue;
    }

    const value = inlineValue ?? argv[index + 1];
    if (value === undefined) {
      throw new Error(`Missing value for --${key}`);
    }

    if (key === "image") {
      args.image.push(value);
    } else if (["api-key", "apikey", "key"].includes(key)) {
      args["api-key"] = value;
    } else {
      args[key] = value;
    }

    if (inlineValue === null) index += 1;
  }

  return args;
}

function readParamsFile(args) {
  const path = args["params-file"];
  if (!path) return {};

  const content = readFileSync(path, "utf8").replace(/^\uFEFF/, "");
  const parsed = JSON.parse(content);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("--params-file must contain a JSON object.");
  }
  return parsed;
}

function firstDefined(...values) {
  for (const value of values) {
    if (value !== undefined && value !== null && value !== "") return value;
  }
  return undefined;
}

function booleanValue(value) {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") return ["1", "true", "yes", "on"].includes(value.toLowerCase());
  return Boolean(value);
}

function normalizeApiKey(value) {
  if (!value) return "";
  return String(value)
    .trim()
    .replace(/^["'`]+|["'`]+$/g, "")
    .replace(/^Bearer\s+/i, "")
    .trim();
}

function getApiKey(args) {
  return normalizeApiKey(args["api-key"]);
}

function normalizeBaseUrl(value) {
  return String(value || "").replace(/\/+$/, "");
}

function getAllowedBaseUrl(args, params) {
  const requested = firstDefined(args["base-url"], args.baseUrl, params.baseUrl, params["base-url"], allowedBaseUrl);
  const normalized = normalizeBaseUrl(requested);
  if (normalized !== allowedBaseUrl) {
    throw new Error(`This skill only supports ${allowedBaseUrl}. Remove the custom base URL or use the 6789api relay key.`);
  }
  return allowedBaseUrl;
}

function normalizeModel(value) {
  const model = String(value || "").trim();
  return modelAliases.get(model.toLowerCase()) || model;
}

function getDesktopPath() {
  if (process.platform === "win32") {
    try {
      const desktop = execFileSync(
        "powershell.exe",
        ["-NoProfile", "-Command", "[Environment]::GetFolderPath('Desktop')"],
        { encoding: "utf8" }
      ).trim();
      if (desktop) return desktop;
    } catch {
      // Fall through to HOME/USERPROFILE.
    }
  }

  return join(process.env.USERPROFILE || process.env.HOME || ".", "Desktop");
}

function getDefaultOutputDir() {
  return join(getDesktopPath(), "Codex中转站生图");
}

function readPrompt(args, params) {
  const inlinePrompt = firstDefined(args.prompt, params.prompt);
  const promptFile = firstDefined(args["prompt-file"], params.promptFile, params["prompt-file"]);

  if (inlinePrompt && promptFile) {
    throw new Error("Use either --prompt or --prompt-file, not both.");
  }

  if (inlinePrompt) return String(inlinePrompt);
  if (promptFile) {
    return readFileSync(promptFile, "utf8").replace(/^\uFEFF/, "");
  }

  throw new Error("Provide --prompt or --prompt-file.");
}

function parsePositiveInteger(value, fallback) {
  const parsed = Number.parseInt(value || "", 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function parseImageCount(value) {
  const text = value === undefined || value === null || value === "" ? "1" : String(value).trim();
  const parsed = Number.parseInt(text, 10);
  if (!Number.isFinite(parsed) || String(parsed) !== text || parsed < 1 || parsed > maxConcurrentImages) {
    throw new Error(`--n must be an integer from 1 through ${maxConcurrentImages}.`);
  }
  return parsed;
}

function parsePerImageTimeout(value) {
  if (value === undefined || value === null || value === "") return maxPerImageTimeoutMs;
  const text = String(value).trim();
  const parsed = Number.parseInt(text, 10);
  if (!Number.isFinite(parsed) || String(parsed) !== text || parsed <= 0) {
    throw new Error("Per-image timeout must be a positive integer in milliseconds.");
  }
  if (parsed > maxPerImageTimeoutMs) {
    throw new Error(`Per-image timeout cannot exceed ${maxPerImageTimeoutMs} ms (10 minutes).`);
  }
  return parsed;
}

function parseMegabytes(value, fallbackBytes) {
  const parsed = Number.parseFloat(value || "");
  return Number.isFinite(parsed) && parsed > 0 ? parsed * 1024 * 1024 : fallbackBytes;
}

function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function assertPayloadBudget({ prompt, images, maxPromptChars, maxImageBytes }) {
  if (prompt.length > maxPromptChars) {
    throw new Error(`Prompt is ${prompt.length} characters; limit is ${maxPromptChars}. Shorten it or raise IMAGE_RELAY_MAX_PROMPT_CHARS.`);
  }

  for (const imagePath of images) {
    if (!existsSync(imagePath)) {
      throw new Error(`Reference image does not exist: ${imagePath}`);
    }

    const bytes = statSync(imagePath).size;
    if (bytes > maxImageBytes) {
      throw new Error(`Reference image is ${formatBytes(bytes)}; limit is ${formatBytes(maxImageBytes)}. Compress it or raise IMAGE_RELAY_MAX_IMAGE_MB.`);
    }
  }
}

function mimeTypeFor(path) {
  const extension = extname(path).toLowerCase();
  if (extension === ".jpg" || extension === ".jpeg") return "image/jpeg";
  if (extension === ".webp") return "image/webp";
  if (extension === ".gif") return "image/gif";
  return "image/png";
}

function isGeminiContentModel(model) {
  return model.startsWith("gemini-") || model.startsWith("nano-banana-");
}

function isOpenAIImageModel(model) {
  return model === "gpt-image-2" || model === "gpt-image-2（官方）";
}

function openAIImageSizeForRatio(ratio) {
  const value = String(ratio || "").trim();
  if (/^\d+x\d+$/i.test(value)) return value.toLowerCase();

  switch (value) {
    case "1:1":
      return "1024x1024";
    case "16:9":
      return "1024x576";
    case "9:16":
      return "576x1024";
    case "3:4":
      return "1008x1344";
    case "4:3":
      return "1024x768";
    case "3:2":
      return "1536x1024";
    case "2:3":
      return "1024x1536";
    case "2k-square":
      return "2048x2048";
    case "2k-landscape":
      return "2048x1152";
    case "4k-landscape":
      return "3840x2160";
    case "4k-portrait":
      return "2160x3840";
    default:
      return undefined;
  }
}

function isGeminiImageSize(value) {
  return ["1K", "2K", "4K"].includes(String(value || "").trim().toUpperCase());
}

function inferAspectRatio(size) {
  const text = String(size || "").trim();
  const match = text.match(/^(\d+)x(\d+)$/i);
  if (!match) return "1:1";

  const width = Number.parseInt(match[1], 10);
  const height = Number.parseInt(match[2], 10);
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) return "1:1";

  const divisor = gcd(width, height);
  return `${width / divisor}:${height / divisor}`;
}

function gcd(a, b) {
  let left = Math.abs(a);
  let right = Math.abs(b);
  while (right !== 0) {
    const next = left % right;
    left = right;
    right = next;
  }
  return left || 1;
}

function buildJsonBody({ model, prompt, size, quality, n, minimal }) {
  const body = { model, prompt };
  if (!minimal) {
    body.size = size;
    body.quality = quality;
    body.n = n;
  }
  return JSON.stringify(body);
}

function buildFormBody({ model, prompt, images, size, quality, n, minimal }) {
  const body = new FormData();
  body.append("model", model);
  body.append("prompt", prompt);

  if (!minimal) {
    body.append("size", size);
    body.append("quality", quality);
    body.append("n", String(n));
  }

  for (const imagePath of images) {
    const buffer = readFileSync(imagePath);
    body.append("image", new Blob([buffer], { type: mimeTypeFor(imagePath) }), basename(imagePath));
  }

  return body;
}

function buildGeminiContentBody({ prompt, images, aspectRatio, imageSize, minimal }) {
  const parts = [{ text: prompt }];

  for (const imagePath of images) {
    const buffer = readFileSync(imagePath);
    parts.push({
      inlineData: {
        mimeType: mimeTypeFor(imagePath),
        data: buffer.toString("base64")
      }
    });
  }

  const body = {
    contents: [
      {
        role: "user",
        parts
      }
    ],
    generationConfig: {
      responseModalities: ["IMAGE"]
    }
  };

  if (!minimal) {
    body.generationConfig.topP = 0.95;
    body.generationConfig.imageConfig = {
      aspectRatio,
      imageSize
    };
  }

  return JSON.stringify(body);
}

async function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function shouldRetry(status) {
  return status === 408 || status === 409 || status === 425 || status === 429 || status >= 500;
}

function remainingTime(deadlineAt) {
  return Math.max(0, deadlineAt - Date.now());
}

function imageTimeoutError() {
  return new Error("Image task exceeded its per-image timeout.");
}

async function callRelay({ endpoint, headers, bodyFactory, deadlineAt, retries }) {
  let lastError = null;

  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const requestTimeoutMs = remainingTime(deadlineAt);
    if (requestTimeoutMs === 0) throw imageTimeoutError();

    try {
      const response = await fetchWithTimeout(endpoint, {
        method: "POST",
        headers,
        body: bodyFactory()
      }, requestTimeoutMs);

      const text = await response.text();
      if (response.ok) return JSON.parse(text);

      const message = `Image API failed: ${response.status} ${response.statusText}\n${text}`;
      if (!shouldRetry(response.status) || attempt === retries) {
        const error = new Error(message);
        error.retryable = false;
        throw error;
      }

      lastError = new Error(message);
    } catch (error) {
      lastError = error;
      if (error?.retryable === false || attempt === retries) throw error;
    }

    const delayMs = Math.min(1000 * 2 ** attempt, 8000, remainingTime(deadlineAt));
    if (delayMs === 0) throw imageTimeoutError();
    await new Promise((resolve) => setTimeout(resolve, delayMs));
  }

  throw lastError || new Error("Image API request failed.");
}

async function saveImage(item, outputDir, prefix, suffix, deadlineAt) {
  if (item.b64_json) {
    return writeImageWithoutOverwrite(
      outputDir,
      `${prefix}-${suffix}`,
      extensionForMimeType(item.mimeType),
      Buffer.from(item.b64_json, "base64")
    );
  }

  if (item.url) {
    const downloadTimeoutMs = remainingTime(deadlineAt);
    if (downloadTimeoutMs === 0) throw imageTimeoutError();
    const response = await fetchWithTimeout(item.url, {}, downloadTimeoutMs);
    if (!response.ok) {
      throw new Error(`Failed to download image URL: ${response.status} ${response.statusText}`);
    }

    const url = new URL(item.url);
    const extension = extname(url.pathname) || ".png";
    const arrayBuffer = await response.arrayBuffer();
    return writeImageWithoutOverwrite(
      outputDir,
      `${prefix}-${suffix}`,
      extension,
      Buffer.from(arrayBuffer)
    );
  }

  throw new Error("Response image item has neither b64_json nor url.");
}

async function writeImageWithoutOverwrite(outputDir, stem, extension, contents) {
  for (let copy = 1; ; copy += 1) {
    const copySuffix = copy === 1 ? "" : `-${String(copy).padStart(2, "0")}`;
    const outputPath = join(outputDir, `${stem}${copySuffix}${extension}`);

    try {
      await writeFile(outputPath, contents, { flag: "wx" });
      return outputPath;
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
    }
  }
}

function extensionForMimeType(mimeType) {
  if (mimeType === "image/jpeg") return ".jpg";
  if (mimeType === "image/webp") return ".webp";
  if (mimeType === "image/gif") return ".gif";
  return ".png";
}

function extractImageItems(result) {
  const items = [];

  if (Array.isArray(result.data)) {
    items.push(...result.data);
  }

  for (const candidate of result.candidates || []) {
    for (const part of candidate?.content?.parts || []) {
      const inlineData = part.inlineData || part.inline_data;
      if (inlineData?.data) {
        items.push({
          b64_json: inlineData.data,
          mimeType: inlineData.mimeType || inlineData.mime_type
        });
      }
    }
  }

  return items;
}

const args = parseArgs(process.argv.slice(2));

if (args.help) {
  console.log(usage);
  process.exit(0);
}

if (args["list-models"]) {
  console.log(knownModels.join("\n"));
  process.exit(0);
}

try {
  const params = readParamsFile(args);
  const prompt = readPrompt(args, params);
  const paramImages = Array.isArray(params.images) ? params.images : [];
  const images = [...paramImages, ...args.image];
  const baseUrl = getAllowedBaseUrl(args, params);
  const model = normalizeModel(firstDefined(args.model, params.model, process.env.IMAGE_RELAY_MODEL, "nano-banana-pro"));
  const requestedRatio = firstDefined(args.ratio, params.ratio);
  const size = firstDefined(
    args.size,
    params.size,
    isOpenAIImageModel(model) ? openAIImageSizeForRatio(requestedRatio) : undefined,
    process.env.IMAGE_RELAY_SIZE,
    "1536x2048"
  );
  const quality = firstDefined(args.quality, params.quality, process.env.IMAGE_RELAY_QUALITY, "high");
  const aspectRatio = firstDefined(args["aspect-ratio"], args.aspectRatio, args.ratio, params.aspectRatio, params["aspect-ratio"], params.ratio, inferAspectRatio(size));
  const imageSize = firstDefined(
    args["image-size"],
    args.imageSize,
    params.imageSize,
    params["image-size"],
    isGeminiContentModel(model) && isGeminiImageSize(quality) ? String(quality).trim().toUpperCase() : undefined,
    "2K"
  );
  const n = parseImageCount(firstDefined(args.n, params.n, 1));
  const outputDir = resolve(firstDefined(args.out, params.out, params.outputDir, process.env.IMAGE_RELAY_OUTPUT_DIR, getDefaultOutputDir()));
  const prefix = firstDefined(args.prefix, params.prefix, `relay-image-${new Date().toISOString().replace(/[:.]/g, "-")}`);
  const timeoutMs = parsePerImageTimeout(firstDefined(args["timeout-ms"], params.timeoutMs, params["timeout-ms"], process.env.IMAGE_RELAY_TIMEOUT_MS));
  const retries = parsePositiveInteger(firstDefined(args.retries, params.retries, process.env.IMAGE_RELAY_RETRIES), 2);
  const maxPromptChars = parsePositiveInteger(firstDefined(args["max-prompt-chars"], params.maxPromptChars, params["max-prompt-chars"], process.env.IMAGE_RELAY_MAX_PROMPT_CHARS), 3500);
  const maxImageBytes = parseMegabytes(firstDefined(args["max-image-mb"], params.maxImageMb, params["max-image-mb"], process.env.IMAGE_RELAY_MAX_IMAGE_MB), 5 * 1024 * 1024);
  const isEdit = images.length > 0;
  const usesGeminiContent = isGeminiContentModel(model);
  const endpoint = usesGeminiContent ? `${betaBaseUrl}/models/${encodeURIComponent(model)}:generateContent` : `${baseUrl}${isEdit ? "/images/edits" : "/images/generations"}`;
  const minimal = Boolean(args.minimal) || booleanValue(params.minimal);

  assertPayloadBudget({ prompt, images, maxPromptChars, maxImageBytes });

  const requestPlan = {
    endpoint,
    model,
    mode: usesGeminiContent ? (isEdit ? "gemini-content-image-edit" : "gemini-content-text-to-image") : (isEdit ? "image-edit" : "text-to-image"),
    promptChars: prompt.length,
    images,
    size: minimal ? null : size,
    quality: minimal ? null : quality,
    aspectRatio: usesGeminiContent && !minimal ? aspectRatio : null,
    imageSize: usesGeminiContent && !minimal ? imageSize : null,
    n,
    concurrency: n,
    relayPayloadN: minimal ? null : 1,
    outputDir,
    prefix,
    perImageTimeoutMs: timeoutMs,
    retries,
    minimal
  };

  if (args["dry-run"]) {
    console.log(JSON.stringify(requestPlan, null, 2));
    process.exit(0);
  }

  const apiKey = getApiKey(args);
  if (!apiKey) {
    throw new Error("API key is required. Ask the user to paste their https://www.6789api.top/v1 API key in the conversation. If they do not have one, ask them to register at https://www.6789api.top/ and create a key.");
  }

  const headers = { Authorization: `Bearer ${apiKey}` };
  let bodyFactory;

  if (usesGeminiContent) {
    headers["Content-Type"] = "application/json";
    bodyFactory = () => buildGeminiContentBody({ prompt, images, aspectRatio, imageSize, minimal });
  } else if (isEdit) {
    bodyFactory = () => buildFormBody({ model, prompt, images, size, quality, n: 1, minimal });
  } else {
    headers["Content-Type"] = "application/json";
    bodyFactory = () => buildJsonBody({ model, prompt, size, quality, n: 1, minimal });
  }

  await mkdir(outputDir, { recursive: true });

  async function generateOne(requestIndex) {
    const deadlineAt = Date.now() + timeoutMs;
    const result = await callRelay({ endpoint, headers, bodyFactory, deadlineAt, retries });
    const data = extractImageItems(result);
    if (data.length === 0) {
      throw new Error(`Image request ${requestIndex + 1} returned no image data.`);
    }

    const requestNumber = String(requestIndex + 1).padStart(2, "0");
    const paths = [];
    for (let itemIndex = 0; itemIndex < data.length; itemIndex += 1) {
      const suffix = data.length === 1
        ? requestNumber
        : `${requestNumber}-${String(itemIndex + 1).padStart(2, "0")}`;
      paths.push(await saveImage(data[itemIndex], outputDir, prefix, suffix, deadlineAt));
    }
    return paths;
  }

  const results = await Promise.allSettled(
    Array.from({ length: n }, async (_, requestIndex) => {
      const paths = await generateOne(requestIndex);
      for (const path of paths) console.log(path);
      return paths;
    })
  );
  const saved = results.flatMap((result) => result.status === "fulfilled" ? result.value : []);
  const failures = results
    .map((result, index) => ({ result, index }))
    .filter(({ result }) => result.status === "rejected");

  for (const { result, index } of failures) {
    const reason = result.reason instanceof Error ? result.reason.message : String(result.reason);
    console.error(`Image request ${index + 1} failed: ${reason}`);
  }

  if (saved.length === 0) {
    throw new Error(`All ${n} image requests failed.`);
  }

} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
}
