#!/usr/bin/env node

import { execFile, spawn } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const scriptsDir = dirname(fileURLToPath(import.meta.url));
const generatorPath = join(scriptsDir, "generate-image.mjs");
const ensurePanelPath = join(scriptsDir, "ensure-panel.mjs");
const allowedArgs = new Set(["prompt", "prompt-file", "api-key", "image", "dry-run", "panel-url"]);
const panelParameterArgs = new Set([
  "model", "size", "quality", "aspect-ratio", "image-size", "n", "out",
  "prefix", "minimal", "base-url", "params-file"
]);

function parseArgs(argv) {
  const args = { image: [] };
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (!item.startsWith("--")) continue;
    const key = item.slice(2);
    if (!allowedArgs.has(key)) {
      if (panelParameterArgs.has(key)) {
        throw new Error(`--${key} cannot be passed here; generation parameters come only from the user's panel settings.`);
      }
      throw new Error(`Unknown argument: --${key}`);
    }
    if (key === "dry-run") {
      args[key] = true;
      continue;
    }
    const value = argv[index + 1];
    if (value === undefined) throw new Error(`Missing value for --${key}`);
    if (key === "image") args.image.push(value);
    else args[key] = value;
    index += 1;
  }
  return args;
}

function normalizePanelUrl(value) {
  const url = new URL(value);
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || !url.port) {
    throw new Error("Persistent parameter panel returned an invalid URL.");
  }
  return `${url.origin}/`;
}

async function readJson(response) {
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || `Panel request failed with ${response.status}.`);
  return value;
}

async function fetchPanelSettings(panelUrl) {
  return readJson(await fetch(new URL("settings", panelUrl), {
    cache: "no-store",
    signal: AbortSignal.timeout(500)
  }));
}

async function postStatus(panelUrl, state, message) {
  if (!panelUrl) return;
  try {
    await fetch(new URL("status", panelUrl), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ state, message }),
      signal: AbortSignal.timeout(300)
    });
  } catch {
    // Status reporting must not delay or fail image generation.
  }
}

function settingsArgs(settings) {
  const count = Number(settings.n);
  if (!Number.isInteger(count) || count < 1 || count > 50) {
    throw new Error("Panel image count must be an integer from 1 through 50.");
  }

  const pairs = [
    ["--model", settings.model],
    ["--size", settings.size],
    ["--quality", settings.quality],
    ["--aspect-ratio", settings.aspectRatio],
    ["--image-size", settings.imageSize],
    ["--n", String(count)],
    ["--prefix", settings.prefix]
  ];
  if (settings.out) pairs.push(["--out", settings.out]);
  if (settings.image) pairs.push(["--image", settings.image]);
  return pairs.flat();
}

function requestArgs(args, settings) {
  const result = settingsArgs(settings);
  if (args.prompt) result.push("--prompt", args.prompt);
  if (args["prompt-file"]) result.push("--prompt-file", args["prompt-file"]);
  for (const image of args.image) result.push("--image", image);
  if (args["api-key"]) result.push("--api-key", args["api-key"]);
  if (args["dry-run"]) result.push("--dry-run");
  return result;
}

function cleanError(error, apiKey) {
  const raw = [error?.stderr, error?.stdout, error?.message].filter(Boolean).join("\n").trim();
  return apiKey ? raw.replaceAll(apiKey, "[redacted]") : raw;
}

function runGenerator(commandArgs) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [generatorPath, ...commandArgs], {
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true
    });
    let stdout = "";
    let stderr = "";

    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
      process.stdout.write(chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", (error) => {
      error.stdout = stdout;
      error.stderr = stderr;
      reject(error);
    });
    child.on("close", (code) => {
      if (code === 0) {
        resolve({ stdout, stderr });
        return;
      }
      const error = new Error(`Image generator exited with code ${code}.`);
      error.stdout = stdout;
      error.stderr = stderr;
      reject(error);
    });
  });
}

async function ensurePanel() {
  const result = await execFileAsync(process.execPath, [ensurePanelPath], {
    encoding: "utf8",
    maxBuffer: 64 * 1024
  });
  const lines = result.stdout.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length === 0) throw new Error("Persistent parameter panel did not return a URL.");
  return normalizePanelUrl(lines.at(-1));
}

let args = { image: [] };
let panelUrl = "";

try {
  args = parseArgs(process.argv.slice(2));
  panelUrl = args["panel-url"] ? normalizePanelUrl(args["panel-url"]) : await ensurePanel();
  const settings = await fetchPanelSettings(panelUrl);
  const commandArgs = requestArgs(args, settings);
  const summary = `${settings.model} · ${settings.ratio || settings.size} · ${settings.quality}`;

  if (!args["dry-run"] && !args["api-key"]) {
    throw new Error("API key is required. Ask the user to paste their 6789api key in the conversation.");
  }

  await postStatus(panelUrl, "running", `正在生成 ${settings.n} 张图片（${summary}）`);

  const result = await runGenerator(commandArgs);

  const output = result.stdout.trim();
  const paths = args["dry-run"] ? [] : output.split(/\r?\n/).filter(Boolean);
  const successMessage = args["dry-run"]
    ? `参数联动测试完成（${summary}）`
    : `生成完成：${paths.length} 张成功（${summary}）`;
  await postStatus(panelUrl, "success", successMessage);
  if (result.stderr) process.stderr.write(result.stderr);
} catch (error) {
  const message = cleanError(error, args["api-key"]);
  if (panelUrl) await postStatus(panelUrl, "error", message.slice(0, 300));
  process.stderr.write(`${message}\n`);
  process.exit(1);
}
