#!/usr/bin/env node

import { createServer } from "node:http";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const host = "127.0.0.1";
const relayBaseUrl = "https://www.6789api.top/v1";
const runtimeDir = join(process.env.CODEX_HOME || join(homedir(), ".codex"), "relay-image-generator");
const statePath = join(runtimeDir, "panel-state.json");
const registryPath = join(runtimeDir, "active-panel.json");
const panelPath = join(dirname(fileURLToPath(import.meta.url)), "..", "assets", "parameter-panel", "index.html");
const panel = await readFile(panelPath);
const startedAt = new Date().toISOString();
let panelUrl = "";
let writeQueue = Promise.resolve();

const defaultActivity = {
  state: "idle",
  message: "等待生成任务",
  entries: []
};
const defaultSettings = {
  aspectRatio: "3:4",
  baseUrl: relayBaseUrl,
  image: "",
  imageSize: "2K",
  model: "nano-banana-pro",
  n: "1",
  out: "",
  prefix: "relay-image",
  quality: "2K",
  ratio: "3:4",
  size: "1536x2048",
  updatedAt: null
};
const settingNames = new Set([
  "aspectRatio", "baseUrl", "image", "imageSize", "model",
  "n", "out", "prefix", "quality", "ratio", "size"
]);

async function readSavedState() {
  try {
    const parsed = JSON.parse(await readFile(statePath, "utf8"));
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (error) {
    if (error?.code !== "ENOENT" && !(error instanceof SyntaxError)) {
      process.stderr.write(`Unable to read saved panel state: ${error.message}\n`);
    }
    return {};
  }
}

function restoreSettings(saved) {
  const result = { ...defaultSettings };
  if (!saved || typeof saved !== "object") return result;

  for (const name of settingNames) {
    if (Object.hasOwn(saved, name)) result[name] = String(saved[name]).slice(0, 4096);
  }
  const count = Number(result.n);
  if (!Number.isInteger(count) || count < 1 || count > 50) result.n = defaultSettings.n;
  result.baseUrl = relayBaseUrl;
  result.updatedAt = typeof saved.updatedAt === "string" ? saved.updatedAt : null;
  return result;
}

function restoreActivity(saved) {
  if (!saved || typeof saved !== "object") return { ...defaultActivity, entries: [] };
  const state = ["idle", "running", "success", "error"].includes(saved.state) ? saved.state : "idle";
  const message = typeof saved.message === "string" && saved.message.trim()
    ? saved.message.trim().slice(0, 500)
    : defaultActivity.message;
  const entries = Array.isArray(saved.entries)
    ? saved.entries.filter((entry) => entry && typeof entry.message === "string").slice(0, 20)
    : [];
  return { state, message, entries };
}

const savedState = await readSavedState();
const settings = restoreSettings(savedState.settings);
const activity = restoreActivity(savedState.activity);

function queueJsonWrite(path, value) {
  const body = `${JSON.stringify(value, null, 2)}\n`;
  writeQueue = writeQueue
    .catch(() => {})
    .then(async () => {
      await mkdir(runtimeDir, { recursive: true });
      await writeFile(path, body, "utf8");
    });
  return writeQueue;
}

async function persistState() {
  const savedAt = new Date().toISOString();
  await queueJsonWrite(statePath, {
    version: 1,
    savedAt,
    settings,
    activity
  });
  if (panelUrl) {
    await queueJsonWrite(registryPath, {
      version: 1,
      panelUrl,
      pid: process.pid,
      startedAt,
      updatedAt: savedAt,
      settingsUpdatedAt: settings.updatedAt,
      statePath
    });
  }
}

function sendJson(response, statusCode, value) {
  const body = Buffer.from(JSON.stringify(value));
  response.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": body.byteLength,
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'none'",
    "X-Content-Type-Options": "nosniff"
  });
  response.end(body);
}

async function readJson(request) {
  const chunks = [];
  let size = 0;

  for await (const chunk of request) {
    size += chunk.byteLength;
    if (size > 16_384) throw new Error("Request is too large.");
    chunks.push(chunk);
  }

  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

const server = createServer(async (request, response) => {
  const pathname = new URL(request.url || "/", `http://${host}`).pathname;

  if (pathname === "/status" && request.method === "GET") {
    sendJson(response, 200, activity);
    return;
  }

  if (pathname === "/status" && request.method === "POST") {
    try {
      const update = await readJson(request);
      const message = typeof update.message === "string" ? update.message.trim().slice(0, 500) : "";
      const state = ["idle", "running", "success", "error"].includes(update.state) ? update.state : activity.state;

      if (!message) {
        sendJson(response, 400, { error: "message is required" });
        return;
      }

      activity.state = state;
      activity.message = message;
      activity.entries.unshift({ at: new Date().toISOString(), state, message });
      activity.entries = activity.entries.slice(0, 20);
      await persistState();
      sendJson(response, 200, activity);
    } catch (error) {
      sendJson(response, 400, { error: error instanceof Error ? error.message : "Invalid request" });
    }
    return;
  }

  if (pathname === "/settings" && request.method === "GET") {
    sendJson(response, 200, settings);
    return;
  }

  if (pathname === "/settings" && request.method === "POST") {
    try {
      const update = await readJson(request);
      const nextCount = Number(update.n);

      if (!Number.isInteger(nextCount) || nextCount < 1 || nextCount > 50) {
        sendJson(response, 400, { error: "n must be an integer from 1 through 50" });
        return;
      }
      if (update.baseUrl !== relayBaseUrl) {
        sendJson(response, 400, { error: "baseUrl must use the fixed 6789api relay" });
        return;
      }

      for (const name of settingNames) {
        if (Object.hasOwn(update, name)) settings[name] = String(update[name]).slice(0, 4096);
      }
      settings.updatedAt = new Date().toISOString();
      await persistState();
      sendJson(response, 200, settings);
    } catch (error) {
      sendJson(response, 400, { error: error instanceof Error ? error.message : "Invalid request" });
    }
    return;
  }

  if (request.method !== "GET" || (pathname !== "/" && pathname !== "/index.html")) {
    response.writeHead(404, {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store"
    });
    response.end("Not found");
    return;
  }

  response.writeHead(200, {
    "Content-Type": "text/html; charset=utf-8",
    "Content-Length": panel.byteLength,
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; form-action 'none'; base-uri 'none'; frame-ancestors 'none'",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff"
  });
  response.end(panel);
});

server.listen(0, host, async () => {
  const address = server.address();
  if (!address || typeof address === "string") {
    throw new Error("Unable to determine the parameter panel address.");
  }
  panelUrl = `http://${host}:${address.port}/`;
  await persistState();
  console.log(panelUrl);
});

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
